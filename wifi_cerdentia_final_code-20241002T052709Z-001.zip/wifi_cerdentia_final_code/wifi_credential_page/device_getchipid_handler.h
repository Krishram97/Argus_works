#ifndef _device_getchipid_handler_h
#define _device_getchipid_handler_h

void getchipid();

extern uint64_t chip_id;  

#endif
