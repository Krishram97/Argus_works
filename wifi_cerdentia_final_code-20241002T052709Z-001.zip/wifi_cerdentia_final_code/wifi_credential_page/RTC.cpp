#include "RTC.h"

//const char* ssid = "ACT101651126426";
//const char* password = "65125656";

//const char* ntpServer = "in.pool.ntp.org";
//const long gmtoffset_sec = 19800;
//const int  daylightOffset_sec = 0;
struct tm timeinfo;
void printLocalTime()
{
   // Getting the Local Time 
  if(!getLocalTime(&timeinfo)){
    Serial.println("Failed to obtain time");
    return;
  }
  Serial.println(&timeinfo, "%A, %B %d %Y %H:%M:%S");// Separate the date, time, month and day
  
}
// initlization of RTC 
void rtc_init() { 
printLocalTime();
}
// Main RTC
void rtc_main() {
  // put your main code here, to run repeatedly:
  delay(1000);
  printLocalTime();
}
