#ifndef _eeprom_param_handler_h
#define _eeprom_param_handler_h

#define SLAVE_ID_MAX 247      //Maximum slave id entered 255
#define SLAVE_ID_MIN 1        //Minumum slave id entered 1

#define BAUD_MAX_VALUE 4
#define BAUD_MIN_VALUE 0

#define COMM_CONFIG_MAX_VALUE 3
#define COMM_CONFIG_MIN_VALUE 0

#define EOP_TIMER_MAX_VALUE 25
#define EOP_TIMER_MIN_VALUE 3

#define BAUD_RATE_1200   0
#define BAUD_RATE_2400   1
#define BAUD_RATE_4800   2
#define BAUD_RATE_9600   3
#define BAUD_RATE_19200  4


#define SOFTWARE_VERSION_MAX  9
#define SOFTWARE_VERSTION_MIN 1

#define HARDWARE_VERSION_MAX  9
#define HARDWARE_VERSTION_MIN 1

typedef struct
{ 
        uint16_t                MagicNumber;            // 0xBEEF
        //Device Information
        uint16_t                Firmware_Version;       // e.g 10000=V1.00.00
        uint8_t                 Device_Model[20];       // ASCII HEX Value/Register   
        uint16_t                Protocol_Version;       // e.g 100=V1.00
        uint64_t                chipID;                 // MAC address of Device
        time_t                  firmware_update_date;   // UNIX Timestamp
        
        uint8_t                 Wificheckbit;
        //Wifi Settings
        uint8_t                 WifiUsername[64];
        uint8_t                 WifiPassword[64];
        uint8_t                 mqttserver[64];
        uint8_t                 mqttport[4];
        uint8_t                 mqttusername[64];
        uint8_t                 mqttpassword[64];
        uint32_t                energizedtime;       
        uint32_t                unergizedtime;

        //Cumulative Measurements
        uint32_t                channel1_EnergyActive;
        uint32_t                channel1_EnergyReactive;
        uint32_t                channel1_EnergyApparent;

        uint32_t                channel2_EnergyActive;
        uint32_t                channel2_EnergyReactive;
        uint32_t                channel2_EnergyApparent;

        //Modbus coil data
        uint8_t                 coil1;
        uint8_t                 coil2;
        uint8_t                 coil3;
        
        //Device Setup
        uint8_t                 unit_id;
        uint8_t                 baud_rate;
        uint8_t                 comm_config;;
        //uint8_t                 reserved;
        
}tSystemConfiguration, *cfgparam_p;

extern volatile  tSystemConfiguration gSystemConfiguration;

//Default System Configuration.
#define SYSTEM_CONFIG_MAGIC_NUMBER                      0xBEEF

#define SYSTEM_CONFIG_DEVICE_MODEL                      "2SPMC-RS-0"
#define SYSTEM_CONFIG_FIRMWARE_VERSION                  10000
#define SYSTEM_CONFIG_PROTOCOL_VERSION                  100
#define SYSTEM_CONFIG_FIRMWARE_UPDATE_DATE              1620655017
#define SYSTEM_CONFIG_UNIT_ID                           200
#define SYSTEM_CONFIG_BAUD_RATE                         3
#define SYSTEM_CONFIG_COMM_CONFIG                       3
#define WIFI_CHECK_BIT                                  0

#define DEFAULT_SSID                                    "bcs"
#define DEFAULT_PASSWORD                                "bcs"

#define DEFAULT_MQTT_SERVER                             "bcs"
#define DEFAULT_MQTT_USER_NAME                          "bcs"
#define DEFAULT_MQTT_USER_PASS                          "bcs"

#define DEFAULT_ENERGIZED_TIME                          300000
#define DEFAULT_UNENERGIZED_TIME                        30000





void dump_cfg_param_info(void);
void config_param_default_init(void);
void config_param_assigned_init(void);
void cfg_param_read(void);
int cfg_param_write(void);
void update_received_modbus_data(void);
void cap1293both_touchhandler(uint8_t touch_seconds);
void update_touched_relay_data(uint8_t updated_coil,uint8_t coil1,uint8_t coil2);
void update_eeprom_relay_data();

#endif
