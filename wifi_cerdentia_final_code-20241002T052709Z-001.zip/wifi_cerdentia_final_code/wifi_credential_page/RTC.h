#ifndef _RTC_H
#define _RTC_H

#include<WiFi.h>
#include"time.h"

void printLocalTime();
void rtc_init();
void rtc_main();

#endif