#include <WiFi.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include "eeprom_param_handler.h"
#include "wifi_credentials_handler.h"
#include "device_debug_handler.h"
#include "modbus_packet_handler.h"
volatile wifiData_timer_t wifiData_timer;
//Variables
int i = 0,n;
int statusCode;
//String ssid,passphrase;
char ssid[32],passphrase[32];
String st;
String content; 
String esid;
String epass = "";
//Function Decalration
void WiFi_Init(void);
void launchWeb(void);
void setupAP(void);
void createWebServer(void);
void Create_Server(void);
bool testWifi();

//Establishing Local server at port 80
WebServer server(80);

uint8_t check_bit=0;

void WiFi_Init()
{
  check_bit=gSystemConfiguration.Wificheckbit;
  //check_bit=1;
  if(check_bit==1)
  {
      check_bit=0;
      sprintf(ssid,"%s",gSystemConfiguration.WifiUsername,sizeof(gSystemConfiguration.WifiUsername));
      sprintf(passphrase,"%s",gSystemConfiguration.WifiPassword,sizeof(gSystemConfiguration.WifiUsername));
  
      DEBUG_TEST_SERIAL.printf("WIFI_USERNAME: %s \r\n",ssid);
      DEBUG_TEST_SERIAL.printf("WIFI_USERNAME: %s \r\n",passphrase);
      WiFi.begin(ssid,passphrase);
      if(testWifi()==true)
      {
          DEBUG_TEST_SERIAL.print("Connected to ");
          DEBUG_TEST_SERIAL.print(ssid);
          DEBUG_TEST_SERIAL.println(" Successfully");
          delay(100);
      }
  }
  else
  {
    WiFi.softAP(Default_SSID,Default_Password);// Setup HotSpot
    Create_Server();
  }
}

void Create_Server() {   
    DEBUG_TEST_SERIAL.println("Connection Status Negative / Check bit Low");
    DEBUG_TEST_SERIAL.println("Turning the HotSpot On");
    setupAP();
    launchWeb();
    DEBUG_TEST_SERIAL.println();
    DEBUG_TEST_SERIAL.println("Waiting.");
    
    while ((WiFi.status() != WL_CONNECTED))
    {
      //if(Modbus_RS485Interface.RxInterfaceEvent == 0)    //checks rs485data
      //{
        //Modbus_RS485Interface.rs485choice=0;
              DEBUG_TEST_SERIAL.print(".");
              delay(100);
              server.handleClient();
      //}
    /*  else
      {
        WiFi.softAPdisconnect(true);
       // Modbus_RS485Interface.rs485choice=1;
        break;
      
    }  */
    }
     WiFi.softAPdisconnect(true);
       // Modbus_RS485Interface.rs485choice=1;
    
    delay(1000);
}


bool testWifi(void)
{
  int c = 0;
  //DEBUG_TEST_SERIAL.println("Waiting for Wifi to connect");
  while ( c < 100 ) {
    if (WiFi.status() == WL_CONNECTED)
    {
      return true;
    }
    delay(500);
    DEBUG_TEST_SERIAL.print("*");
    c++;
  }
  DEBUG_TEST_SERIAL.println("");
  DEBUG_TEST_SERIAL.println("Connect timed out, opening AP");
  return false;
}



void launchWeb()
{
  DEBUG_TEST_SERIAL.print("Local IP: ");
  DEBUG_TEST_SERIAL.println(WiFi.localIP());
  DEBUG_TEST_SERIAL.print("SoftAP IP: ");
  DEBUG_TEST_SERIAL.println(WiFi.softAPIP());
  createWebServer();
  
  // Start the server
  server.begin();
  DEBUG_TEST_SERIAL.println("Server started");
}



void setupAP(void)
{
  delay(100);
  n = WiFi.scanNetworks();
  //DEBUG_TEST_SERIAL.println(n);
  DEBUG_TEST_SERIAL.println("scan done");
  if(n==0)
  {
    DEBUG_TEST_SERIAL.println("no networks found");
  }
  else
  {
    DEBUG_TEST_SERIAL.print(n);
    DEBUG_TEST_SERIAL.println(" networks found");
    for (int i = 0; i < n; ++i)
    {
      // Print SSID and RSSI for each network found
      DEBUG_TEST_SERIAL.print(i + 1);
      DEBUG_TEST_SERIAL.print(": ");
      DEBUG_TEST_SERIAL.print(WiFi.SSID(i));
      DEBUG_TEST_SERIAL.print(" (");
      DEBUG_TEST_SERIAL.print(WiFi.RSSI(i));
      DEBUG_TEST_SERIAL.println(")");
      //DEBUG_TEST_SERIAL.println((WiFi.encryptionType(i) == ENC_TYPE_NONE) ? " " : "*");
      delay(10);
    }
  }
  DEBUG_TEST_SERIAL.println("");
  st = "<ol>";
  for (int i = 0; i < n; ++i)
  {
    // Print SSID and RSSI for each network found
    st += "<li>";
    st += WiFi.SSID(i);
    st += " (";
    st += WiFi.RSSI(i);
    st += ")";
    //st += (WiFi.encryptionType(i) == ENC_TYPE_NONE) ? " " : "*";
    st += "</li>";
  }
  st += "</ol>";
  delay(100);
  DEBUG_TEST_SERIAL.println("Initializing_softap_for_wifi credentials_modification");
  //launchWeb();
  DEBUG_TEST_SERIAL.println("over");
}



void createWebServer()
{
  {
    server.on("/", []() {
      IPAddress ip = WiFi.softAPIP();
      String ipStr = String(ip[0]) + '.' + String(ip[1]) + '.' + String(ip[2]) + '.' + String(ip[3]);
      content = "<!DOCTYPE HTML>\r\n<html>Welcome to AIQUA Smart Meter Wifi Credentials Update page";
      //content += "<form action=\"/scan\" method=\"POST\"><input type=\"submit\" value=\"scan\"></form>";
      //content += ipStr;
      content += "<p>";
      content += "scan done ";
      content += n;
      content += " networks found";
      content += "<p>";
      content += st;
      content += "</p><form method='get' action='setting1'><label>SSID:<li>                        </label><input name='ssid'     length=32><input name='pass'     length=64><input type=\"submit\" value=\"update\"></form>";
      content += "<p>";
      content += "</p><form method='get' action='setting2'><label>MQTT Server URL&Port:<li>        </label><input name='mqtturl'  length=32><input name='mqttport' length=64><input type=\"submit\" value=\"update\"></form>";
      content += "<p>";
      content += "</p><form method='get' action='setting3'><label>MQTT User&Password:<li>          </label><input name='mqttuser' length=32><input name='mqttpass' length=64><input type=\"submit\" value=\"update\"></form>";
      content += "<p>";
      content += "</p><form method='get' action='setting4'><label>Energized & UnEnergized Time:<li></label><input name='energ'    length=32><input name='unenerg'  length=64><input type=\"submit\" value=\"update\"></form>";
      content += "<p>";
      content += "<p>";
      content += "<p>";
      content += "<form action=\"/exit\" method=\"POST\"><input type=\"submit\" value=\"exit\"></form>";
      content += "</html>";
      server.send(200, "text/html", content);
    });

    //scan
    server.on("/scan", []() {
      setupAP();
      IPAddress ip = WiFi.softAPIP();
      String ipStr = String(ip[0]) + '.' + String(ip[1]) + '.' + String(ip[2]) + '.' + String(ip[3]);
      content = "<!DOCTYPE HTML>\r\n<html>go back";
      server.send(200, "text/html", content);
    });
    //exit
    server.on("/exit", []() {
      content = "<!DOCTYPE HTML>\r\n<html>Thank you";
      server.send(200, "text/html", content);
      delay(1000);
      ESP.restart();
    });
   
    //setting1
    server.on("/setting1", []() {
      String qsid = server.arg("ssid");
      String qpass = server.arg("pass");
      
      if (qsid.length() > 0 && qpass.length() > 0) {
        DEBUG_TEST_SERIAL.println(qsid);
        DEBUG_TEST_SERIAL.println("");
        DEBUG_TEST_SERIAL.println(qpass);
        DEBUG_TEST_SERIAL.println("");

        DEBUG_TEST_SERIAL.println("writing eeprom ssid:");
        qsid.toCharArray((char *)gSystemConfiguration.WifiUsername,sizeof(gSystemConfiguration.WifiUsername));

        DEBUG_TEST_SERIAL.println("writing eeprom pass:");
        qpass.toCharArray((char *)gSystemConfiguration.WifiPassword,sizeof(gSystemConfiguration.WifiPassword));
        
        
        DEBUG_TEST_SERIAL.printf("WIFI_USERNAME: %s \r\n",(char*)gSystemConfiguration.WifiUsername);
        DEBUG_TEST_SERIAL.printf("WIFI_USERNAME: %s \r\n",(char*)gSystemConfiguration.WifiPassword);
        
        gSystemConfiguration.Wificheckbit=1;//Saved SSID & Password
        cfg_param_write();
        
        content = "{\"Success\":\"saved to eeprom... go back for exit or update anothe parameters\"}";
        statusCode = 200;
        //ESP.restart();
      } 
      else {
        content = "{\"Error\":\"404 not found\"}";
        statusCode = 404;
        DEBUG_TEST_SERIAL.println("Sending 404");
       }
      server.sendHeader("Access-Control-Allow-Origin", "*");
      server.send(statusCode, "application/json", content);
    });

    //setting2
    server.on("/setting2", []() {
      String qmqtturl = server.arg("mqtturl");
      String qmqttport = server.arg("mqttport");
     
      if (qmqtturl.length() > 0 && qmqttport.length() > 0) {

        DEBUG_TEST_SERIAL.println(qmqtturl);
        DEBUG_TEST_SERIAL.println("");
        DEBUG_TEST_SERIAL.println(qmqttport);
        DEBUG_TEST_SERIAL.println("");

        DEBUG_TEST_SERIAL.println("writing eeprom mqtturl:");
        qmqtturl.toCharArray((char *)gSystemConfiguration.mqttserver,sizeof(gSystemConfiguration.mqttserver));
        
        DEBUG_TEST_SERIAL.println("writing eeprom mqttport:");
        qmqttport.toCharArray((char *)gSystemConfiguration.mqttport,(sizeof(gSystemConfiguration.mqttport)+1));
        cfg_param_write();
        
        DEBUG_TEST_SERIAL.printf("MQTT_URL : %s \r\n",(char*)gSystemConfiguration.mqttserver);
        DEBUG_TEST_SERIAL.printf("MQTT_PORT: %s \r\n",(char*)gSystemConfiguration.mqttport);
        content = "{\"Success\":\"saved to eeprom... go back for exit or update anothe parameters\"}";
        statusCode = 200;
        //ESP.restart();
      } else {
        content = "{\"Error\":\"404 not found\"}";
        statusCode = 404;
        DEBUG_TEST_SERIAL.println("Sending 404");
      }
      server.sendHeader("Access-Control-Allow-Origin", "*");
      server.send(statusCode, "application/json", content);
    });

    //setting3
    server.on("/setting3", []() {
      String qmqttuser = server.arg("mqttuser");
      String qmqttpass = server.arg("mqttpass");
     
      if (qmqttuser.length() > 0 && qmqttpass.length() > 0) {

        DEBUG_TEST_SERIAL.println(qmqttuser);
        DEBUG_TEST_SERIAL.println("");
        DEBUG_TEST_SERIAL.println(qmqttpass);
        DEBUG_TEST_SERIAL.println("");

        DEBUG_TEST_SERIAL.println("writing eeprom mqtturl:");
        qmqttuser.toCharArray((char *)gSystemConfiguration.mqttusername,sizeof(gSystemConfiguration.mqttusername));
        
        DEBUG_TEST_SERIAL.println("writing eeprom mqttport:");
        qmqttpass.toCharArray((char *)gSystemConfiguration.mqttpassword,sizeof(gSystemConfiguration.mqttpassword));
        cfg_param_write();
        
        DEBUG_TEST_SERIAL.printf("MQTT_USERNAME : %s \r\n",(char*)gSystemConfiguration.mqttusername);
        DEBUG_TEST_SERIAL.printf("MQTT_PASSWORD : %s \r\n",(char*)gSystemConfiguration.mqttpassword);
        content = "{\"Success\":\"saved to eeprom... go back for exit or update anothe parameters\"}";
        statusCode = 200;
        //ESP.restart();
      } else {
        statusCode = 404;
        DEBUG_TEST_SERIAL.println("Sending 404");
        content = "{\"Error\":\"404 not found\"}";
      }
      server.sendHeader("Access-Control-Allow-Origin", "*");
      server.send(statusCode, "application/json", content);
    });

    //setting4
    server.on("/setting4", []() {
      String qenerg = server.arg("energ");
      String qunenerg = server.arg("unenerg");
      
      char energ[32],unenerg[32];
      
      if (qenerg.length() > 0 && qunenerg.length() > 0) {

        DEBUG_TEST_SERIAL.println(qenerg);
        DEBUG_TEST_SERIAL.println("");
        DEBUG_TEST_SERIAL.println(qunenerg);
        DEBUG_TEST_SERIAL.println("");

        DEBUG_TEST_SERIAL.println("writing eeprom energized time:");
        //qenerg.toCharArray((char *)gSystemConfiguration.energizedtime,sizeof(gSystemConfiguration.energizedtime));
        qenerg.toCharArray((char *)energ,sizeof(energ));
        
        DEBUG_TEST_SERIAL.println("writing eeprom Unenergized time:");       
        //qunenerg.toCharArray((char *)gSystemConfiguration.unergizedtime,sizeof(gSystemConfiguration.unergizedtime));
        qenerg.toCharArray((char *)unenerg,sizeof(unenerg));
        
        gSystemConfiguration.energizedtime=atoi(energ);
        gSystemConfiguration.unergizedtime=atoi(unenerg);
        cfg_param_write();

        DEBUG_TEST_SERIAL.printf("ENERGIZED_TIME  : %s \r\n",(char*)energ);
        DEBUG_TEST_SERIAL.printf("UNENERGIZED_TIME: %s \r\n",(char*)unenerg);
        
        DEBUG_TEST_SERIAL.printf("ENERGIZED_TIME  : %d \r\n",gSystemConfiguration.energizedtime);
        DEBUG_TEST_SERIAL.printf("UNENERGIZED_TIME: %d \r\n",gSystemConfiguration.unergizedtime);
        
         statusCode = 200;
        //ESP.restart();
      } else {
        content = "{\"Error\":\"404 not found\"}";
        statusCode = 404;
        DEBUG_TEST_SERIAL.println("Sending 404");
      }
      server.sendHeader("Access-Control-Allow-Origin", "*");
      server.send(statusCode, "application/json", content);
    });
    
  }
}
