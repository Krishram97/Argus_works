 #ifndef __modbus_packet_handler_h
#define __modbus_packet_handler_h

#include <stdio.h>

#define  MODBUS_RS485_INTERFACE_MAX_LEN    255

#define REGISTER_0  0
#define REGISTER_2  2
#define REGISTER_4  4
#define REGISTER_6  6
#define REGISTER_8  8

#define REGISTER_10 10
#define REGISTER_12 12
#define REGISTER_14 14
#define REGISTER_16 16
#define REGISTER_18 18

#define REGISTER_20 20
#define REGISTER_22 22
#define REGISTER_24 24
#define REGISTER_26 26
#define REGISTER_28 28


/* Exported types ----------------------------------------------------------- */
typedef struct {
  uint8_t   InterfaceType;
  uint8_t   InterfaceAddress;
  uint8_t   TxPointer;
  uint8_t   RxPointer;

  uint8_t   RxCount;
  uint8_t   TxCount;
  uint8_t   RxInterfaceEvent;
  uint8_t   TxInterfaceEvent;
  uint8_t   rs485choice;
  

  uint8_t   RxBuffer[MODBUS_RS485_INTERFACE_MAX_LEN+1];
  uint8_t   TxBuffer[MODBUS_RS485_INTERFACE_MAX_LEN+1];
  uint8_t   RawRxBuffer[MODBUS_RS485_INTERFACE_MAX_LEN+1];
  uint8_t   RawTxBuffer[MODBUS_RS485_INTERFACE_MAX_LEN+1];    

  uint32_t        EOP_Timer;
  uint16_t        responsetimeout;
  uint16_t        rs485choicetimeout;
  uint8_t         responsetimeoutevent;
} tModbus_RS485Interface, *ptModbus_RS485Interface;

typedef union { 
    float f; 
    struct
    { 
  
        // Order is important. 
        // Here the members of the union data structure 
        // use the same memory (32 bits). 
        // The ordering is taken 
        // from the LSB to the MSB. 
        unsigned int mantissa : 23; 
        unsigned int exponent : 8; 
        unsigned int sign : 1; 
  
    } raw; 
} myfloat;
  
/* Exported Variables ------------------------------------------------------- */
extern  volatile  tModbus_RS485Interface  Modbus_RS485Interface;
extern  volatile uint8_t dev_slave_id;
extern volatile uint8_t dev_slave_id_updated,dev_baud_rate_updated,rs485_comm_config_updated;

/* Exported functions ------------------------------------------------------- */
void Modbus_RS485PacketHandler(void);
void Modbus_RS485DataHandler(void);

#endif
