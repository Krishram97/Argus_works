#ifndef saturation_h
#define saturation_h

#include "stdint.h"
/******************************************************************************/
/*                                FUNCTION BODY                               */
/******************************************************************************/
uint32_t saturation(uint32_t Value,
                   uint32_t Min,
                   uint32_t Max);
#endif
