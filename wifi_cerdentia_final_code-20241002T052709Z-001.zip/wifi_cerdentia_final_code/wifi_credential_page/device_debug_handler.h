#ifndef _device_debug_handler_h
#define _device_debug_handler_h

#include<Arduino.h>

#define DEBUG_BAUDRATE 115200

#define DEBUG true
#define DEBUG_SERIAL if(DEBUG)Serial

#define DEBUG_TEST true
#define DEBUG_TEST_SERIAL if(DEBUG_TEST)Serial

#define DEBUG_IMPORTANT true
#define DEBUG_SERIAL_IMP if(DEBUG)Serial

#endif
