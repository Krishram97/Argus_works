#include <EEPROM.h>
#include "device_debug_handler.h"
#include "device_eeprom_handler.h"

char eRead[READ_MAXSIZE];

// Saves string do EEPROM
void Save_String(uint16_t startAt, uint8_t* id,uint16_t len)
{
  //DEBUG_SERIAL.println(strlen(id));
  for (uint16_t i = 0; i <len; i++)
  {
    EEPROM.write(i + startAt, id[i]);
    //DEBUG_SERIAL.println(id[i]);
  }
  EEPROM.commit();
}

// Reads string from EEPROM
void Read_String(uint8_t* eBuffer, uint16_t startAt, uint16_t bufor)
{
  for (uint16_t i = 0; i <bufor; i++)
  {
    eRead[i] = (char)EEPROM.read(i + startAt);
    eBuffer[i]=eRead[i];
   // DEBUG_SERIAL.println(eBuffer[i]);
  }
  //len = bufor;
}

//Saves byte to EEPROM
void Save_Byte(int startAt, byte val)
{
  EEPROM.write(startAt, val);
  EEPROM.commit();
}

//Reads byte from EEPROM
byte Read_Byte(byte startAt)
{
  byte Read = -1;
  Read = EEPROM.read(startAt);
  return Read;
}

void Eeprom_Init()
{
  EEPROM.begin(512);
}

void Eeprom_Clear(){
        DEBUG_TEST_SERIAL.println("Clearing EEPROM..");
        for (int i = 0; i < 512; i++) { EEPROM.write(i, 0); }
        //EEPROM.commit();
        delay(10);
}
