 #include <WiFi.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include "mqtt_Server.h"
#include <WebServer.h>
#include "eeprom_param_handler.h"
#include "wifi_credentials_handler.h"
#include "device_debug_handler.h"
#include "modbus_packet_handler.h"
#include "device_eeprom_handler.h"
extern char Read;
extern uint8_t RawRxBuffer[256];
String inputString = "";
bool stringComplete = false;
char *p = NULL;
char result;
char mqttpassword[64];
char mqttusername[64];
char mqtturl[64];
char mqttport[64];
//extern tm timeinfo;
void printLocalTime();
const char *mqtt_broker = "broker.hivemq.com";
       int  mqtt_port = 1883;
const char *topic = "test/topic1";
const char *topic2 = "retest/topic1";
const char  *mqtt_username = "ShareGill";
const char  *mqtt_password = "vikram@1974";
extern volatile  tSystemConfiguration gSystemConfiguratio; 
WiFiClient espClient;
PubSubClient client(espClient);
// MQTT intilization
void mqtt_init()
{
    inputString.reserve(200);
    Sesmicon_InterfaceUART_Init();//interface UART init of sesmicon
    Serial.available();
    //WiFi_Init();
    client.setServer(mqtt_broker, mqtt_port);
    //client.setCallback(callback);
    while (!client.connected()) {
        String client_id = "esp32-client-";
        client_id += String(WiFi.macAddress());
        Serial.printf("The client %s connects to the public mqtt broker\n", client_id.c_str());
        if (client.connect(client_id.c_str(), mqtt_username, mqtt_password)) {
            Serial.println("Public emqx mqtt broker connected");
        }
        else {
            Serial.print("failed with state ");
            Serial.print(client.state());
            delay(2000);
        }
    }
}
/*void serialEvent()
{
    while (Serial.available()) {
        // get the new byte:
        char inChar = (char)Serial.read();
        // add it to the inputString:
        inputString += inChar;
        // if the incoming character is a newline, set a flag so the main loop can
        // do something about it:
        if (inChar == '\n') {
            stringComplete = true;
        }
    }
}*/
//MQTT Loop running
void mqtt()
{
    char data_1[50];
    //serialEvent();
    char* rest = (char*)RawRxBuffer;
   

    
    if (stringComplete) {
        p = strtok(rest, ",");//delimiter 
        
        if (!strncmp("$$$SESMI", rest, 7))//string n comparison 
        {
            p = strtok(NULL, ",");
            Serial.print(p); Serial.println();
        
            if (!strncmp("MQTT", p, 4))//Command MQTT,P then sensor data will be sending mqtt
            {
                p = strtok(NULL, ",");
                Serial.print(p); Serial.println();
                if (!strncmp("P", p, 1))
                {
                    p = strtok(NULL, ";");
                    Serial.println(p); Serial.println();
                    client.publish(topic, p);//client publish topic is p
                }
            }
            
            else if(!strncmp("WiFi", p, 1))// This Command WiFi,h it restart
            {
              p = strtok(NULL, ",");
              Serial.println(p); Serial.println();
              if(!strncmp("h", p, 1))
              {
                p = strtok(NULL, ";");
                Serial.println(p); Serial.println();

                //esp restart
                config_param_default_init();
                cfg_param_write();
                delay(1000);
                ESP.restart();
              }
            }
            
            else if(!strncmp("data",p, 1))// this command data,S that uart transmit.
            {                                                                                                                                                                                                                                                                                                                                                                                                                                  
                p = strtok(NULL, ",");
                Serial.println(p);Serial.println();
                if(!strncmp("S",p,1))
                {
                      
                  uart_transmit(); // transmit uart  
                  
                }
                else if(!strncmp("RTC",p,1))
              {
                Serial.println("Entered");
                uart_timestamp();// tranmsiting of time stamp                
              }
            }
}
printLocalTime();// print of local time
inputString = "";// Sting of input
stringComplete = false;
Client_handling();
}
 client.loop();    
}
// Client handling (WIFI)
void Client_handling()
{
    //WiFi_Init();
    //connecting to a mqtt broker
    client.setServer(mqtt_broker, mqtt_port);
    //client.setCallback(callback);
    while (!client.connected()) {
        String client_id = "esp32-client-";
        client_id += String(WiFi.macAddress());//client id mac address
        Serial.printf("The client %s connects to the public mqtt broker\n", client_id.c_str());
        if (client.connect(client_id.c_str(), mqtt_username, mqtt_password)) 
        {
            Serial.println("Public emqx mqtt broker connected");
        }
        else {
            Serial.print("failed with state ");
            Serial.print(client.state());// state of client
            delay(2000);
        }
    }
}
