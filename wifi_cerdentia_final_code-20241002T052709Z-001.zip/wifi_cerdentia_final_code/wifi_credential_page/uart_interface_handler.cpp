#include "device_debug_handler.h"
#include "driver/uart.h"
#include "eeprom_param_handler.h"
#include "RTC.h"

const char* ntpServer = "in.pool.ntp.org";//ntp server gmt time 
const long gmtoffset_sec = 19800;// gmt time ofset seconds gmt(+5:30)
const int  daylightOffset_sec = 0;// daylight off set 
void printLocalTime();
extern bool stringComplete;
volatile char DebugBuffer[1026];
static void UART_ISR_ROUTINE1(void *pvParameters);
#define NUMERO_PORTA_DEBUG_SERIALE1 UART_NUM_1
#define BUF_SIZE1 (1024 * 2)
#define RD_BUF_SIZE1 (1024)
uint8_t RxCount;
uint8_t TxCount;
extern char mqttusername[64],mqttpassword[64];
extern char mqtturl[64];
extern char mqttport[64];
extern tm timeinfo;
static QueueHandle_t uart1_queue;

static const char * TAG1 = "";

#define U1RXD 17   //TTL RX
#define U1TXD 16   //TTL TX

uint8_t RawRxBuffer[256];     //Reception buffer
uint8_t RawTxBuffer[256];
uint16_t rx_fifo_len1;        //Data length

//void data_receivedfromfinger();

 
void Sesmicon_InterfaceUART_Init() {
       
  
      uart_parity_t parity;
      uart_stop_bits_t stopbit;
      parity   =  UART_PARITY_DISABLE;
      stopbit  =  UART_STOP_BITS_1;
      /*
      switch(rs485_comm_config)
      {
      case 0: parity   =  UART_PARITY_DISABLE;
              stopbit  =  UART_STOP_BITS_2;
      break;
      
      case 1: parity   =  UART_PARITY_ODD;
              stopbit  =  UART_STOP_BITS_1;
  
      break;
      
      case 2: parity   =  UART_PARITY_EVEN;
              stopbit  =  UART_STOP_BITS_1;
      break;
      
      case 3: parity   =  UART_PARITY_DISABLE;
              stopbit  =  UART_STOP_BITS_1;
      break;
      
      }*/
      
     //Configuro la porta DEBUG_SERIAL2 (tutti i parametri hanno anche un get per effettuare controlli)
     uart_config_t Configurazione_UART1 = {  
      .baud_rate = 115200,
      .data_bits = UART_DATA_8_BITS,  
      .parity = parity,  
      .stop_bits = stopbit,  
      .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
      };
    
    uart_param_config(NUMERO_PORTA_DEBUG_SERIALE1, &Configurazione_UART1);
    //Firma: void esp_log_level_set(const char *TAG2, esp_log_level_tlevel)
    esp_log_level_set(TAG1, ESP_LOG_INFO);
    //Firma: esp_err_tuart_set_pin(uart_port_tuart_num, int tx_io_num, int rx_io_num, int rts_io_num, int cts_io_num)
    uart_set_pin(NUMERO_PORTA_DEBUG_SERIALE1, U1TXD, U1RXD, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    //Firma: uart_driver_install(UART_NUM_2, uart_buffer_size, uart_buffer_size, 10, &uart_queue, 0));
    //       uart_driver_install(Numero_porta, RXD_BUFFER, TXD_Buffer, event queue handle and size, flags to allocate an interrupt)
    uart_driver_install(NUMERO_PORTA_DEBUG_SERIALE1, BUF_SIZE1, BUF_SIZE1, 20, &uart1_queue, 0);
    //Create a task to handler UART event from ISR
    xTaskCreate(UART_ISR_ROUTINE1, "UART_ISR_ROUTINE1", 2048, NULL, 12, NULL);
}

 
 static void UART_ISR_ROUTINE1(void *pvParameters)
{
    uart_event_t event;
    size_t buffered_size;
    bool exit_condition = false;
    //uint8_t* dtmp = (uint8_t*)malloc(RD_BUF_SIZE1);
    //Infinite loop to run main bulk of task
    while (1) {
     Serial.print("UART_ISR");
        //Loop will continually block (i.e. wait) on event messages from the event queue
        if(xQueueReceive(uart1_queue, (void * )&event, (portTickType)portMAX_DELAY)) {
        Serial.println("Done"); 
            if (event.type == UART_DATA) {      

                ESP_ERROR_CHECK(uart_get_buffered_data_len(UART_NUM_1, (size_t*)&  RxCount));
                RxCount = uart_read_bytes(UART_NUM_1, (uint8_t*)RawRxBuffer,   RxCount, 100);
                stringComplete=true;
                
            }
           
            //Handle frame error event
            else if (event.type == UART_FRAME_ERR) {
                //TODO...
            }
           
            //Keep adding else if statements for each UART event you want to support
            //else if (event.type == OTHER EVENT) {
                //TODO...
            //}
           
           
            //Final else statement to act as a default case
            else {
                //TODO...
            }      
        }
       
        //If you want to break out of the loop due to certain conditions, set exit condition to true
        if (exit_condition) {
            break;
        }
    }
   
    //Out side of loop now. Task needs to clean up and self terminate before returning
    vTaskDelete(NULL);
}


void uart_transmit(void)
{
  //Converting the charater into string and pass the value by constant character
  
   sprintf(mqttusername,"%s",gSystemConfiguration.mqttusername,sizeof(gSystemConfiguration.mqttusername));
      sprintf(mqttpassword,"%s",gSystemConfiguration.mqttpassword,sizeof(gSystemConfiguration.mqttpassword));
      sprintf(mqtturl,"%s",gSystemConfiguration.mqttserver,sizeof(gSystemConfiguration.mqttserver));
      sprintf(mqttport,"%s",gSystemConfiguration.mqttport,sizeof(gSystemConfiguration.mqttport));
      
   //wirte byte through uart to write on UART port   
  uart_write_bytes(UART_NUM_1, "$$data", (size_t)sizeof("$$data"));
  uart_write_bytes(UART_NUM_1, "Username", (size_t)sizeof("Username"));
  uart_write_bytes(UART_NUM_1, (const char*)&mqttusername, (size_t)sizeof(mqttusername));//uart write bytes of mqttusername
  uart_write_bytes(UART_NUM_1, "Password", (size_t)sizeof("Password"));
  uart_write_bytes(UART_NUM_1, (const char*)&mqttpassword, (size_t)sizeof(mqttpassword));// uart write bytes of mqttpassword
  uart_write_bytes(UART_NUM_1, "URL", (size_t)sizeof("URL"));
  uart_write_bytes(UART_NUM_1, (const char*)&mqtturl, (size_t)sizeof(mqtturl));// uart write bytes  of mqtt url 
  uart_write_bytes(UART_NUM_1, "Port", (size_t)sizeof("Port"));
  uart_write_bytes(UART_NUM_1, (const char*)&mqttport, (size_t)sizeof(mqttport));// uart write bytes of mqttport
                  
}
void uart_timestamp(void)
{
  char time_string[65];
  configTime(gmtoffset_sec, daylightOffset_sec, ntpServer);//configuration of time using gmt
  printLocalTime();//It prints the Local time
  sprintf(time_string,"S:%d,M:%d,Hour:%d,Month:%d,Week:%d,Year:%d\r\n",timeinfo.tm_sec,timeinfo.tm_min,timeinfo.tm_hour,timeinfo.tm_mon,timeinfo.tm_wday,timeinfo.tm_year);//convert character to string  
 
  
  uart_write_bytes(UART_NUM_1,(const char*)&time_string,90);//time string write bytes 
}
