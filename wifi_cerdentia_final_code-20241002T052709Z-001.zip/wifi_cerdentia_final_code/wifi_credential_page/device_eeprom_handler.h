#ifndef _device_eeprom_handler_h
#define _device_eeprom_handler_h

#define READ_MAXSIZE  510

void Save_String(uint16_t startAt, uint8_t* id,uint16_t len);
void Read_String(uint8_t* eBuffer, uint16_t startAt, uint16_t bufor);
void Save_Byte(int startAt, byte val);
byte Read_Byte(byte startAt);
void Eeprom_Init();
void Eeprom_Clear();

#endif
