#ifndef _MQTT_Server_H_
#define _MQTT_Server_H_

#include "Arduino.h"

#include "WiFi.h"
#include "PubSubClient.h"
#include <string.h>

void Sesmicon_InterfaceUART_Init();
void uart_transmit(void);
void uart_timestamp(void);
void mqtt_init();
void mqtt();
void serialEvent();
void Client_handling();
void WiFi_Init();
void Create_Server();
#endif
