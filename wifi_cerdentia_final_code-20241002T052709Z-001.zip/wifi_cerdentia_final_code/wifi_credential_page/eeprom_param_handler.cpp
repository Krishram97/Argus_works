#include "device_debug_handler.h"-
#include "eeprom_param_handler.h"
#include "device_eeprom_handler.h"
#include "device_getchipid_handler.h"
/*#include "saturation.h"
#include "device_relay_handler.h"
#include "device_led_handler.h"
#include "device_ticker_handler.h"*/
#include "saturation.h"

volatile   tSystemConfiguration gSystemConfiguration;
volatile uint8_t dev_slave_id,dev_baud_rate,rs485_comm_config;
volatile uint8_t coil_data,powercontrolcoils_updated;
volatile uint8_t dev_slave_id_updated,dev_baud_rate_updated,rs485_comm_config_updated;
volatile uint32_t rs485_baud_rate;
//extern volatile uint8_t RL1,RL2;
extern volatile uint16_t date_modbus_updated,month_modbus_updated,year_modbus_updated,hour_modbus_updated,minutes_modbus_updated,seconds_modbus_updated,day_modbus_updated;

void dump_cfg_param_info(void)
{
  DEBUG_SERIAL_IMP.printf("SYSTEM_CONFIG_MAGIC_NUMBER                  : %x \r\n",(int)gSystemConfiguration.MagicNumber);
  DEBUG_SERIAL_IMP.printf("SYSTEM_CONFIG_CURRENT_VERSION_NUMBER        : %d \r\n",(int)gSystemConfiguration.Firmware_Version);
  DEBUG_SERIAL_IMP.printf("SYSTEM_NAME                                 : %.10s \r\n",(char*)gSystemConfiguration.Device_Model);
  DEBUG_SERIAL_IMP.printf("SYSTEM_ID                                   : %d \r\n",(char*)gSystemConfiguration.Protocol_Version);
  DEBUG_SERIAL_IMP.printf("Device Chip ID                              : %04X",(uint16_t)(gSystemConfiguration.chipID>>32));      //print High 2 bytes
  DEBUG_SERIAL_IMP.printf("%08X\n",(uint32_t)gSystemConfiguration.chipID);//print Low 4bytes.
  return;
}

void config_param_default_init(void)
{
  memset((void *)&gSystemConfiguration,0,sizeof(gSystemConfiguration));
 
  gSystemConfiguration.MagicNumber          = SYSTEM_CONFIG_MAGIC_NUMBER;
  gSystemConfiguration.Firmware_Version     = SYSTEM_CONFIG_FIRMWARE_VERSION;
  gSystemConfiguration.Protocol_Version     = SYSTEM_CONFIG_PROTOCOL_VERSION;
 // gSystemConfiguration.chipID               = chip_id;
  gSystemConfiguration.Wificheckbit         = WIFI_CHECK_BIT;
  gSystemConfiguration.unit_id              = SYSTEM_CONFIG_UNIT_ID;
  gSystemConfiguration.baud_rate            = SYSTEM_CONFIG_BAUD_RATE;
  gSystemConfiguration.comm_config          = SYSTEM_CONFIG_COMM_CONFIG;
  gSystemConfiguration.firmware_update_date = SYSTEM_CONFIG_FIRMWARE_UPDATE_DATE;
  
  strncpy((char*)gSystemConfiguration.Device_Model,SYSTEM_CONFIG_DEVICE_MODEL,sizeof(gSystemConfiguration.Device_Model));
 
  strncpy((char*)gSystemConfiguration.WifiUsername,DEFAULT_SSID,sizeof(gSystemConfiguration.WifiUsername));
  strncpy((char*)gSystemConfiguration.WifiUsername,DEFAULT_PASSWORD,sizeof(gSystemConfiguration.WifiUsername));
 
  strncpy((char*)gSystemConfiguration.WifiUsername,DEFAULT_MQTT_SERVER,sizeof(gSystemConfiguration.WifiUsername));
  strncpy((char*)gSystemConfiguration.mqttusername,DEFAULT_MQTT_USER_NAME,sizeof(gSystemConfiguration.mqttusername));
  strncpy((char*)gSystemConfiguration.mqttpassword,DEFAULT_MQTT_USER_PASS,sizeof(gSystemConfiguration.mqttpassword));

  gSystemConfiguration.energizedtime =DEFAULT_ENERGIZED_TIME;
  gSystemConfiguration.unergizedtime =DEFAULT_UNENERGIZED_TIME;

}

void config_param_default_init_for_30sec(void)
{
 
  gSystemConfiguration.MagicNumber          = SYSTEM_CONFIG_MAGIC_NUMBER;
  gSystemConfiguration.Firmware_Version     = SYSTEM_CONFIG_FIRMWARE_VERSION;
  gSystemConfiguration.Protocol_Version     = SYSTEM_CONFIG_PROTOCOL_VERSION;
  gSystemConfiguration.Wificheckbit         = WIFI_CHECK_BIT;
  gSystemConfiguration.unit_id              = SYSTEM_CONFIG_UNIT_ID;
  gSystemConfiguration.baud_rate            = SYSTEM_CONFIG_BAUD_RATE;
  gSystemConfiguration.comm_config          = SYSTEM_CONFIG_COMM_CONFIG;
  gSystemConfiguration.firmware_update_date = SYSTEM_CONFIG_FIRMWARE_UPDATE_DATE;
  
  strncpy((char*)gSystemConfiguration.Device_Model,SYSTEM_CONFIG_DEVICE_MODEL,sizeof(gSystemConfiguration.Device_Model));
 
  strncpy((char*)gSystemConfiguration.WifiUsername,DEFAULT_SSID,sizeof(gSystemConfiguration.WifiUsername));
  strncpy((char*)gSystemConfiguration.WifiUsername,DEFAULT_PASSWORD,sizeof(gSystemConfiguration.WifiUsername));
 
  strncpy((char*)gSystemConfiguration.WifiUsername,DEFAULT_MQTT_SERVER,sizeof(gSystemConfiguration.WifiUsername));
  strncpy((char*)gSystemConfiguration.mqttusername,DEFAULT_MQTT_USER_NAME,sizeof(gSystemConfiguration.mqttusername));
  strncpy((char*)gSystemConfiguration.mqttpassword,DEFAULT_MQTT_USER_PASS,sizeof(gSystemConfiguration.mqttpassword));

  gSystemConfiguration.energizedtime =DEFAULT_ENERGIZED_TIME;
  gSystemConfiguration.unergizedtime =DEFAULT_UNENERGIZED_TIME;

}

void cfg_param_read(void)
{
  uint8_t buf1[READ_MAXSIZE];
  
  int* buf = (int*)&gSystemConfiguration;
  int  len  = sizeof(gSystemConfiguration);
  
  Read_String(buf1,0,len); //Read Data from EEPROM
    
  DEBUG_TEST_SERIAL.println(sizeof(gSystemConfiguration));
  memcpy(buf,buf1,sizeof(gSystemConfiguration));

}

int cfg_param_write(void)
{
  //DEBUG_SERIAL.println((uint8_t *)gSystemConfiguration);
  //DEBUG_SERIAL.println(sizeof(gSystemConfiguration));
  Save_String(0,(uint8_t *)&gSystemConfiguration,sizeof(gSystemConfiguration));
}
